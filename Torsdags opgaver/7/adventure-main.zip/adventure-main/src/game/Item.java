package game;

public class Item {

    // Attributes
    private String name;
    private String description;

    // _____________________________________________

    public Item(String description) {
        this(description,description.substring(description.lastIndexOf(' ')+1));
    }

    // _____________________________________________

    public Item(String description, String name) {
        this.name = name;
        this.description = description;
    }

    // _____________________________________________

    public String getName() {
        return name;
    }

    // _____________________________________________

    public String getDescription() {
        return description;
    }

    // _____________________________________________

    @Override
    public String toString() {
        return description;
    }

}

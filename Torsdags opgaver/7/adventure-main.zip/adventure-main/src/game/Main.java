/*

    Author: CPHJL325 // Jonas Meinert Larsen
    Torsdagsopgave

    Comments:
    Lavede til Unit Tests fungerede, og ikke mere. Håber det er okay.
    Min kat døde desværre af hjertestop, så jeg har det lidt dårligt.


*/

package game;

public class Main {

    // Attributes

    // ________________________________

    public static void main(String[] args) {
        new Adventure().startGame();
    }
}